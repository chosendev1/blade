<form class="page-search-form" role="search">
  <div class="input-search input-search-dark">
    <i class="input-search-icon md-search" aria-hidden="true"></i>
    <input type="text" class="form-control" id="inputSearch" name="search" placeholder="Search Customers">
    <button type="button" class="input-search-close icon md-close" aria-label="Close"></button>
  </div>
</form>
