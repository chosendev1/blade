@section('page-header')
	@include('layouts.partials.header',['header' => $header])
	@endsection
	{{-- @section('list-header')
	<h4 class="example-title">
		{{ $list_title }}
	</h4>
	<hr>
	@endsection --}}
