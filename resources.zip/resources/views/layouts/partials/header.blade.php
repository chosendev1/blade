<div class="page-header">
        <h1 class="page-title">{{ $header }}</h1>
        <!-- <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../index.html">Home</a></li>
          <li class="breadcrumb-item"><a href="javascript:void(0)">Forms</a></li>
          <li class="breadcrumb-item active">Layouts</li>
        </ol>
        <div class="page-header-actions">
          <button type="button" class="btn btn-sm btn-icon btn-primary btn-round" data-toggle="tooltip"
            data-original-title="Edit">
            <i class="icon md-edit" aria-hidden="true"></i>
          </button>
          <button type="button" class="btn btn-sm btn-icon btn-primary btn-round" data-toggle="tooltip"
            data-original-title="Refresh">
            <i class="icon md-refresh-alt" aria-hidden="true"></i>
          </button>
          <button type="button" class="btn btn-sm btn-icon btn-primary btn-round" data-toggle="tooltip"
            data-original-title="Setting">
            <i class="icon md-settings" aria-hidden="true"></i>
          </button>
        </div> -->
      </div>
