<ul class="nav nav-tabs nav-tabs-line" role="tablist">
  <!-- <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#loan_details"
      aria-controls="all_contacts" role="tab">Loan Details</a></li> -->
  <li class="nav-item" role="presentation"><a class="active nav-link" data-toggle="tab" href="#approval" aria-controls="approval"
      role="tab">Approval</a></li>
  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#disbursement" aria-controls="disbursement"
      role="tab">Disbursement</a></li>
  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#payments"
      aria-controls="payments" role="tab">Payments</a></li>
  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#guarantors" aria-controls="guarantors"
      role="tab">Guarantors</a></li>
  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#collaterals" aria-controls="collaterals"
      role="tab">Collaterals</a></li>
  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#reject" aria-controls="reject"
      role="tab">Reject</a></li>
  <!-- <li class="dropdown nav-item" role="presentation">
    <a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#" aria-expanded="false">Contacts </a>
    <div class="dropdown-menu" role="menu">
      <a class="dropdown-item" data-toggle="tab" href="#all_contacts" aria-controls="all_contacts"
        role="tab">All Contacts</a>
      <a class="active dropdown-item" data-toggle="tab" href="#my_contacts" aria-controls="my_contacts"
        role="tab">My Contacts</a>
      <a class="dropdown-item" data-toggle="tab" href="#google_contacts" aria-controls="google_contacts"
        role="tab">Google Contacts</a>
    </div>
  </li> -->
</ul>
