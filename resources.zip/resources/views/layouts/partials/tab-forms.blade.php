<div class="card">
	<div class="card-block">
		@yield('tab-page-header')
	</div>
	<div class="card-block">
		@yield('tab-content')
	</div>
</div>
