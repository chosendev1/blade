	@section('tab-page-header')
		<div class="card-header card-header-transparent card-header-bordered">
	      <h4>{{ $tab_title }}</h4>
	    </div>
	@endsection
