<div class="tab-pane animation-fade active" id="guarantors" role="tabpanel">
  @include('loans.guarantor_form')
</div>
