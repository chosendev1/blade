<div class="tab-pane animation-fade active" id="collaterals" role="tabpanel">
  @include('loans.collateral_form',['loan_id' => $loan])
</div>
