<div class="tab-pane animation-fade active" id="all_contacts" role="tabpanel">
  @include('loans.approval_form')
  <!-- <nav>
    <ul data-plugin="paginator" data-total="50" data-skin="pagination-no-border"></ul>
  </nav> -->
</div>
