<div class="tab-pane animation-fade active" id="disbursement" role="tabpanel">
  @include('loans.disbursement_form',['loan_id' => $loan])
</div>
