<div class="tab-pane animation-fade active" id="approval" role="tabpanel">
  @include('loans.approval_form',['loan_id' => $loan_id])
  <!-- <nav>
    <ul data-plugin="paginator" data-total="50" data-skin="pagination-no-border"></ul>
  </nav> -->
</div>
