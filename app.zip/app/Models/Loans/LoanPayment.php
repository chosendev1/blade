<?php

namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanPayment extends Model
{
    //
}
