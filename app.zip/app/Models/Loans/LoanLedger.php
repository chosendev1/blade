<?php

namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;
use App\Models\Loans\LoanProducts;
use App\Models\Loans\Schedule;
use Carbon\Carbon;

class LoanLedger extends Model
{
    public function loanLedger()
    {
    	
    }

}
