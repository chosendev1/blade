<?php

namespace App\Models\CashAccounts;

use Illuminate\Database\Eloquent\Model;

class CashAccount extends Model
{
    //
}
