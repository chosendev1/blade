<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Loans\LoanApplications;
use App\Models\Payments\Payments;
use App\Models\Loans\LoanLedger;

class LoanLedgerController extends Controller
{
    public function loanLedger()
    {	
    	get schedule
    	get Payments

    }
}
